package com.example.controlhome2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.OnLifecycleEvent;

import android.os.Handler;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView webView = findViewById(R.id.webview);
        webView.setWebViewClient(new WebViewClient());

        //Enable JavaScript
        webView.getSettings().setJavaScriptEnabled(true);
        //Enable Cache
        webView.getSettings().setDomStorageEnabled(true);
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "http://192.168.0.110:80/updateServer";

        // Request a string response from the provided URL.
        StringRequest stringRequest =
            new StringRequest(Request.Method.GET, url,
            new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    System.out.println(response);
                    if(response.equals("ControlHome")){
                        webView.loadUrl("http://192.168.0.110:80/");
                    }else{
                        System.out.println("Caiu no else do onCreate");
                        webView.loadUrl("http://7b00.ngrok.io");
                    }
                }
            }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("Servidor nao encontrado");
                webView.loadUrl("http://7b00.ngrok.io");
            }
        });

        // Add the request to the RequestQueue.
        queue.add(stringRequest);

        // Create the Handler object (on the main thread by default)
        Handler handler = new Handler();
        // Define the code block to be executed
        Runnable runnableCode = new Runnable() {
            @Override
            public void run() {
            System.out.println("Requisitou o servidor");
            String url = "http://192.168.0.110:80/updateServer";

            // Request a string response from the provided URL.
            StringRequest stringRequest =
                    new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            System.out.println("Request local");
                        }
                    }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            System.out.println("Request remoto");
            webView.loadUrl("http://7b00.ngrok.io/updateServer");
            }
            });
            // Add the request to the RequestQueue.
            queue.add(stringRequest);
            handler.postDelayed(this, 60000);
            }
        };
        // Start the initial runnable task by posting through the handler
        handler.post(runnableCode);
    }

    @Override
    public void onResume(){
        super.onResume();
        System.out.println("Retomou a pagina1");

        setContentView(R.layout.activity_main);
        WebView webView = findViewById(R.id.webview);
        webView.setWebViewClient(new WebViewClient());

        //Enable JavaScript
        webView.getSettings().setJavaScriptEnabled(true);
        // Instantiate the RequestQueue
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "http://192.168.0.110:80/updateServer";

        // Request a string response from the provided URL.
        StringRequest stringRequest =
            new StringRequest(Request.Method.GET, url,
            new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                System.out.println("Antes:"+ response+":Depois");
                if(response.equals("ControlHome")){
                    webView.loadUrl("http://192.168.0.110:80/");
                }else{
                    System.out.println("Caiu no else do onResume");
                    webView.loadUrl("http://7b00.ngrok.io");
                }}
            }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("Servidor nao encontrado");
                webView.loadUrl("http://7b00.ngrok.io");
            }
        });
        queue.add(stringRequest);
    }
}
