#!/usr/bin/python3
# -*- coding: utf-8 -*-

import paho.mqtt.client as mqtt
from flask import Flask, jsonify, render_template, redirect, url_for, request, session
from functools import wraps
from flask_socketio import SocketIO, emit
from ipaddress import IPv4Address
import json
import sqlite3
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime
from pytz import utc

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)


#Login required
def login_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if (request.remote_addr and request.remote_addr != '127.0.0.1') or ('logged_in' in session):
            return f(*args, **kwargs)
        else:
            return redirect(url_for('login'))
    return wrap

def dict_factory(cursor, row):
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d

# The callback for when the client receives a CONNACK response from the server.
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    client.subscribe("/esp8266/temperature")
    client.subscribe("/esp8266/humidity")
    client.subscribe("/esp8266/dhtreadings")
    client.subscribe("/esp8266/bedroom/temperature")
    client.subscribe("/esp8266/bedroom/humidity")

# The callback for when a PUBLISH message is received from the ESP8266.
def on_message(client, userdata, message):
    #socketio.emit('my variable')
    #print("Received message '" + str(message.payload) + "' on topic '"
    #    + message.topic + "' with QoS " + str(message.qos))
    
    if message.topic == "/esp8266/dhtreadings":
        print("DHT readings update")
        dhtreadings_json = json.loads(message.payload)
        conn=sqlite3.connect('home-database.db')
        c=conn.cursor()
        c.execute("""INSERT INTO readingsTH (temperature,
            humidity, date, time, device) VALUES((?), (?), date(CURRENT_TIMESTAMP,'localtime'),
            time(CURRENT_TIMESTAMP,'localtime'), (?))""", (dhtreadings_json['temperature'],
            dhtreadings_json['humidity'], 'esp8266_1') )
        conn.commit()
        conn.close()
    
    if message.topic == "/esp8266/temperature":
        print("temperature update")
        socketio.emit('dht_temperature', {'data': message.payload})
    if message.topic == "/esp8266/humidity":
        print("humidity update")
        socketio.emit('dht_humidity', {'data': message.payload})
        
    if message.topic == "/esp8266/bedroom/temperature":
        print("bedroom temperature update")
        socketio.emit('dht_bedroomtemperature', {'data': message.payload})
    if message.topic == "/esp8266/bedroom/humidity":
        print("bedroom humidity update")
        socketio.emit('dht_bedroomhumidity', {'data': message.payload})
        
mqttc=mqtt.Client()
mqttc.on_connect = on_connect
mqttc.on_message = on_message
mqttc.connect("localhost",1883,60)
mqttc.loop_start()

# Create a dictionary called pins to store the pin number, name, and pin state:
pins = {
   1 : {'name' : 'Luz quarto',      'board' : 'esp8266', 'topic' : '/esp8266/1', 'state' : 'False'}, 
   2 : {'name' : 'Ar quarto',       'board' : 'esp8266', 'topic' : '/esp8266/2', 'state' : 'False'}, 
   3 : {'name' : 'Persiana quarto', 'board' : 'esp8266', 'topic' : '/esp8266/3', 'state' : 'False'}, 
   4 : {'name' : 'Luz sala',        'board' : 'esp8266', 'topic' : '/esp8266/4', 'state' : 'False'},
   5 : {'name' : 'Ar sala',         'board' : 'esp8266', 'topic' : '/esp8266/5', 'state' : 'False'},
   6 : {'name' : 'UpdateTH',        'board' : 'esp8266', 'topic' : '/esp8266/6', 'state' : 'False'},
   7 : {'name' : 'Luz cozinha',     'board' : 'esp8266', 'topic' : '/esp8266/7', 'state' : 'False'},
   8 : {'name' : 'Ar cozinha',      'board' : 'esp8266', 'topic' : '/esp8266/8', 'state' : 'False'}
       }

# Put the pin dictionary into the template data dictionary:
templateData = {
   'pins' : pins
   }

#print 'templateData', templateData

# Page login and password
@app.route('/login', methods=['GET', 'POST'])
def login():
    
    if (request.remote_addr and request.remote_addr != '127.0.0.1') or ('logged_in' in session):
        return redirect(url_for('index'))
    else: 
        error = None
        if request.method == 'POST':
            if request.form['username'] != 'jean' or request.form['password'] != 'jean':
                error = 'Usuario e senha invalidos, tente novamente.'
            else:
                session['logged_in'] = True
                return redirect(url_for('index'))
        return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

@app.route('/', methods=['GET', 'POST'])
@login_required
def index():
    #Verify user request
    global userRemote
    if request.remote_addr and (request.remote_addr != '127.0.0.1'):
        userRemote = 'false'
    else: 
        userRemote = 'true'
    
    #Show button logout
    if 'logged_in' in session:
        logged = 'True'
    else:
        logged = 'False'
         
    if request.method == 'POST':
        mqttc.publish('/esp8266/6',"0")
        #Force update temperature and humidity
        if request.form.get('luzSala'): 
            if request.form['luzSala'] == 'Desligar':
                mqttc.publish(pins[4]['topic'],"0")
                pins[4]['state'] = 'False'
            elif request.form['luzSala'] == 'Ligar':
                mqttc.publish(pins[4]['topic'],"1")
                pins[4]['state'] = 'True'
        elif request.form.get('arSala'):
            if request.form['arSala'] == 'Desligar':
                mqttc.publish(pins[5]['topic'],"0")
                pins[5]['state'] = 'False'
            elif request.form['arSala'] == 'Ligar':
                mqttc.publish(pins[5]['topic'],"1")
                pins[5]['state'] = 'True'     
    else:
        mqttc.publish('/esp8266/6',"0")
        #Force update temperature and humidity
    
    templateData = {
        'pins' : pins
    }  
   
    return render_template('index.html', userRemote=userRemote, logged=logged, async_mode=socketio.async_mode, **templateData)

@app.route('/bedroom', methods=['GET', 'POST'])
@login_required
def bedroom():
    #Verify user request
    global userRemote
    if request.remote_addr and (request.remote_addr != '127.0.0.1'):
        userRemote = 'false'
    else: 
        userRemote = 'true'
    
    #Show button logout
    if 'logged_in' in session:
        logged = 'True'
    else:
        logged = 'False'
        
    if request.method == 'POST':
        mqttc.publish('/esp8266/bedroom/update',"0")       
        #Force update temperature and humidity
        if request.form.get('luzQuarto'):
          if request.form['luzQuarto'] == 'Desligar':
               mqttc.publish(pins[1]['topic'],"0")
               pins[1]['state'] = 'False'
          elif request.form['luzQuarto'] == 'Ligar':
               mqttc.publish(pins[1]['topic'],"1")
               pins[1]['state'] = 'True'
        if request.form.get('arQuarto'):
          if request.form['arQuarto'] == 'Desligar':
               mqttc.publish(pins[2]['topic'],"0")
               pins[2]['state'] = 'False'
          elif request.form['arQuarto'] == 'Ligar':
               mqttc.publish(pins[2]['topic'],"1")
               pins[2]['state'] = 'True'
        if request.form.get('persianaQuarto'):
          if request.form['persianaQuarto'] == 'Desligar':
               mqttc.publish(pins[3]['topic'],"0")
               pins[3]['state'] = 'False'
          elif request.form['persianaQuarto'] == 'Ligar':
               mqttc.publish(pins[3]['topic'],"1")
               pins[3]['state'] = 'True'     
    else:
        mqttc.publish('/esp8266/bedroom/update',"0")
        #Force update temperature and humidity
    
    templateData = {
        'pins' : pins
    }  
   
    return render_template('bedroom.html', userRemote=userRemote, logged=logged, async_mode=socketio.async_mode, **templateData)


@app.route('/kitchen', methods=['GET', 'POST'])
@login_required
def kitchen():
    #Verify user request
    global userRemote
    if request.remote_addr and (request.remote_addr != '127.0.0.1'):
        userRemote = 'false'
    else: 
        userRemote = 'true'
    
    #Show button logout
    if 'logged_in' in session:
        logged = 'True'
    else:
        logged = 'False'
        
    if request.method == 'POST':
        if request.form.get('luzCozinha'):       
          if request.form['luzCozinha'] == 'Desligar':
               mqttc.publish(pins[7]['topic'],"0")
               pins[7]['state'] = 'False'
          elif request.form['luzCozinha'] == 'Ligar':
               mqttc.publish(pins[7]['topic'],"1")
               pins[7]['state'] = 'True'
        if request.form.get('arCozinha'):
          if request.form['arCozinha'] == 'Desligar':
               mqttc.publish(pins[8]['topic'],"0")
               pins[8]['state'] = 'False'
          elif request.form['arCozinha'] == 'Ligar':
               mqttc.publish(pins[8]['topic'],"1")
               pins[8]['state'] = 'True'
    else:
        mqttc.publish('/esp8266/6',"0")
        #Force update temperature and humidity
    
    templateData = {
        'pins' : pins
    }  
   
    return render_template('kitchen.html', userRemote=userRemote, logged=logged, async_mode=socketio.async_mode, **templateData)


@app.route("/<board>/<changePin>/<action>")
@login_required
def action(board, changePin, action):
   # Convert the pin from the URL into an integer:
   changePin = int(changePin)
   # Get the device name for the pin being changed:
   devicePin = pins[changePin]['name']
   # If the action part of the URL is "on," execute the code indented below:
   if action == "1" and board == 'esp8266':
      mqttc.publish(pins[changePin]['topic'],"1")
      pins[changePin]['state'] = 'True'

   if action == "0" and board == 'esp8266':
      mqttc.publish(pins[changePin]['topic'],"0")
      pins[changePin]['state'] = 'False'

   # Along with the pin dictionary, put the message into the template data dictionary:
   templateData = {
      'pins' : pins
   }

   return render_template('index.html', async_mode=socketio.async_mode, **templateData)

# Funcao para ligar/desligar o ar condicionado da sala
def powerAir(whenRun, action, idDelete, device):
    
    global userRemote
    
    print('Quando: ' + whenRun)
    print('Acao: ' + action)
    print('Id: ' + idDelete)
    print('Dispositivo: ' + device)
    
    #Executa a acao
    if ((whenRun == 'perfil' and userRemote == 'true') or (whenRun == 'sempre')):
        if (action == 'ligar'):   
            if (device == 'Luz quarto'):
                mqttc.publish(pins[1]['topic'],"1")
                pins[1]['state'] = 'True'
            elif (device == 'Ar quarto'):
                mqttc.publish(pins[2]['topic'],"1")
                pins[2]['state'] = 'True'
            elif (device == 'Persiana quarto'):
                mqttc.publish(pins[3]['topic'],"1")
                pins[3]['state'] = 'True'
            elif (device == 'Luz sala'):    
                mqttc.publish(pins[4]['topic'],"1")
                pins[4]['state'] = 'True'
            elif (device == 'Ar sala'):
                mqttc.publish(pins[5]['topic'],"1")
                pins[5]['state'] = 'True'    
        elif (action == 'desligar'):
            if (device == 'Luz quarto'):
                mqttc.publish(pins[1]['topic'],"0")
                pins[1]['state'] = 'False'
            elif (device == 'Ar quarto'):
                mqttc.publish(pins[2]['topic'],"0")
                pins[2]['state'] = 'False'
            elif (device == 'Persiana quarto'):
                mqttc.publish(pins[3]['topic'],"0")
                pins[3]['state'] = 'False'
            elif (device == 'Luz sala'):    
                mqttc.publish(pins[4]['topic'],"0")
                pins[4]['state'] = 'False'
            elif (device == 'Ar sala'):
                mqttc.publish(pins[5]['topic'],"0")
                pins[5]['state'] = 'False'    
                

    if idDelete != '' and idDelete != '0': 
        print('ID PARA DELETAR: ' + idDelete)
        #Deleta o agendamento da base
        idDelete = int(idDelete)       
        conn=sqlite3.connect('home-database.db')
        c=conn.cursor()
        c.execute("""DELETE FROM schedules WHERE id = ?""", (idDelete,))
        conn.commit()
        conn.close()
    
    
    templateData = {
        'pins' : pins
    }  
   

@app.route("/taskSchedulerOne",  methods=['GET', 'POST'])
@login_required
def taskSchedulerOne():
    #Verify user request
    global userRemote
    if request.remote_addr and (request.remote_addr != '127.0.0.1'):
        userRemote = 'false'
    else: 
        userRemote = 'true'
    
    msg = None
    action = None
    
    if request.method == 'POST':
       dateTimeHTML = request.form['dateHourStart']
       device = request.form['devices']
       
       if dateTimeHTML != '' and device != '':
           dateTimeRun = dateTimeHTML[0:10] + ' ' + dateTimeHTML[11:16] + ':00'
           action = request.form['action']
           
           #global sched
           sched = BackgroundScheduler(daemon=True, timezone=utc)
           sched.add_job(powerAir,'date', run_date=dateTimeRun, args=['sempre', action, '0', device])
           sched.start()
           msg = 'Agendamento realizado com sucesso.'
           
           print('------------------Verificacao de agendamento unico -----------------------')
           print('Data e hora ' + dateTimeRun)
           print('Acao: ' + action)
           print('Dispositivo: ' + device)
       else:
            msg = 'Nao foi possivel realizar o agendamento.'
               
    return render_template('taskSchedulerOne.html', msg=msg, userRemote=userRemote)
   
@app.route("/taskSchedulerDays",  methods=['GET', 'POST'])
@login_required
def taskSchedulerDays():
    #Verify user request
    global userRemote
    if request.remote_addr and (request.remote_addr != '127.0.0.1'):
        userRemote = 'false'
    else: 
        userRemote = 'true'
    
    msg = None
    whenRun = None 
    action = None
    if request.method == 'POST':
       TimeStart = request.form['hourStart']
       EndDate = request.form['endDate']
       device = request.form['devices']
       DaysOfWeek = ''
       DiasSemana = ''
       if request.form.get('sun'):
           DaysOfWeek = 'sun'
           DiasSemana = 'Dom'
       if request.form.get('mon'):
           DaysOfWeek = DaysOfWeek + ' mon'
           DiasSemana = DiasSemana + ' Seg'
       if request.form.get('tue'):
           DaysOfWeek = DaysOfWeek + ' tue'
           DiasSemana = DiasSemana + ' Ter'
       if request.form.get('wed'):
           DaysOfWeek = DaysOfWeek + ' wed'
           DiasSemana = DiasSemana + ' Qua'
       if request.form.get('thu'):
           DaysOfWeek = DaysOfWeek + ' thu'
           DiasSemana = DiasSemana + ' Qui'
       if request.form.get('fri'):
           DaysOfWeek = DaysOfWeek + ' fri'
           DiasSemana = DiasSemana + ' Sex'
       if request.form.get('sat'):
           DaysOfWeek = DaysOfWeek + ' sat'
           DiasSemana = DiasSemana + ' Sab'        
    
       if TimeStart != '' and EndDate != '' and DaysOfWeek != '' and device != '':
           
           print('Dispositivooooooooooooooo: ' + device)
           Hour = TimeStart[0:2]
           Minute = TimeStart[3:5]
           
           whenRun = request.form['whenRun']
           action = request.form['action']
           
           
           print('------------------Verificacao de agendamento periodico -----------------------')
           print('Dias da semana: ' + DaysOfWeek),
           print('Hora: ' + Hour)
           print('Minuto: ' + Minute)
           print('Data final: ' + EndDate)
           print('Quando rodar: ' + whenRun)
           print('Acao: ' + action)
           print('Dispositivo: ' + device)
           
           #Consulta o id e incremeta
           conn=sqlite3.connect('home-database.db')
           c=conn.cursor()
           c.execute("SELECT max(id) FROM schedules")
           record = c.fetchone()
           if record[0] != None:
               newId = str(record[0] + 1)
           else:
               newId = str(1)
               
           c.close()
           
           #Agenda a tarefa no agendador
           #global sched
           sched = BackgroundScheduler(daemon=True, timezone=utc)
           sched.add_job(powerAir,'cron', day_of_week=DaysOfWeek, hour=Hour, minute=Minute , end_date=EndDate, id=newId, args=[whenRun, action, newId, device])
           sched.start()
           
           print('IDDDD DO AGENDAMENTO: ' + newId)
           #Insere a tarefa na tabela de agendamentos
           conn=sqlite3.connect('home-database.db')
           c=conn.cursor()
           c.execute("""INSERT INTO schedules (device, daysWeek, timeStart, endDate, whenRun, action) 
           VALUES((?), (?), (?), (?), (?), (?))""", ('Ar sala', DiasSemana, TimeStart, EndDate, whenRun, action))
           conn.commit()
           conn.close()

           msg = 'Agendamento realizado com sucesso.'
       else:
            msg = 'Nao foi possivel realizar o agendamento.'
               
    return render_template('taskSchedulerDays.html', msg=msg, userRemote=userRemote)

@app.route("/schedules", methods=['GET', 'POST'])
@login_required
def schedules():
   #Verify user request
    global userRemote
    if request.remote_addr and (request.remote_addr != '127.0.0.1'):
        userRemote = 'false'
    else: 
        userRemote = 'true'    
    
    conn=sqlite3.connect('home-database.db')
    conn.row_factory = dict_factory
    c=conn.cursor()
    c.execute("SELECT * FROM schedules ORDER BY id DESC")
    records = c.fetchall()
    c.close()
    
    sched = BackgroundScheduler(daemon=True)
    sched.print_jobs()
    
    if request.method == 'POST':
       idDelete = request.form['excluir']
       idDeleteInt = int(idDelete)
       
       conn=sqlite3.connect('home-database.db')
       c=conn.cursor()
       c.execute("""DELETE FROM schedules WHERE id = ?""", (idDeleteInt,))
       conn.commit()
       conn.close()
       
       #global sched
       sched = BackgroundScheduler(daemon=True)
       sched.print_jobs()
       #sched.remove_job(idDelete)
       
       try:
        sched.remove_job(idDelete)
        print('Agendamento removido')

       except:
        print('Agendamento não removido')

       return redirect(url_for('schedules'))
    
    return render_template('schedules.html', records=records, userRemote=userRemote)
   
   
@app.route("/updateServer")
@login_required
def updateServer():   
    #Verify user request
    global userRemote
    if request.remote_addr and (request.remote_addr != '127.0.0.1'):
        userRemote = 'false'
    else: 
        userRemote = 'true'   
   
    return ('ControlHome', 200)   
   
@app.route("/chartOfTemperature")
@login_required
def chartOfTemperature():
   #Verify user request
    global userRemote
    if request.remote_addr and (request.remote_addr != '127.0.0.1'):
        userRemote = 'false'
    else: 
        userRemote = 'true'
   
    legend = 'Temperatura C'
    conn=sqlite3.connect('home-database.db')
    conn.row_factory = dict_factory
    c=conn.cursor()
    c.execute("SELECT temperature, strftime('%H', time) AS hour FROM readingsTH WHERE date >= datetime('now','-2 day') ORDER BY id LIMIT 300")
    #c.execute("SELECT temperature, strftime('%H', time) AS hour FROM readingsTH WHERE strftime('%d', date) = strftime('%d', 'now') ORDER BY id LIMIT 1500")
    #c.execute("SELECT temperature, strftime('%H', time) AS hour FROM readingsTH ORDER BY id DESC LIMIT 1500")
    readings = c.fetchall()
    c.close()
    
    return render_template('chartOfTemperature.html', readings=readings,  legend=legend, userRemote=userRemote)

@app.route("/chartOfHumidity")
@login_required
def chartOfHumidity():
   #Verify user request
    global userRemote
    if request.remote_addr and (request.remote_addr != '127.0.0.1'):
        userRemote = 'false'
    else: 
        userRemote = 'true' 
    
    legend = 'Umidade %'
    conn=sqlite3.connect('home-database.db')
    conn.row_factory = dict_factory
    c=conn.cursor()
    c.execute("SELECT humidity, strftime('%H', time) AS hour FROM readingsTH WHERE date >= datetime('now','-2 day') ORDER BY id LIMIT 300")
    #c.execute("SELECT * FROM readingsTH ORDER BY id DESC LIMIT 500")
    readings = c.fetchall()
    c.close()
    
    return render_template('chartOfHumidity.html', readings=readings,  legend=legend, userRemote=userRemote)


@app.route("/readingsTH")
@login_required
def readingsTH():
   #Verify user request
    global userRemote
    if request.remote_addr and (request.remote_addr != '127.0.0.1'):
        userRemote = 'false'
    else: 
        userRemote = 'true' 
    
    conn=sqlite3.connect('home-database.db')
    conn.row_factory = dict_factory
    c=conn.cursor()
    c.execute("SELECT * FROM readingsTH WHERE date >= datetime('now','-2 day') ORDER BY id DESC LIMIT 1500")
    readings = c.fetchall()
    c.close()

    return render_template('readingsTH.html', readings=readings, userRemote=userRemote)

@socketio.on('my event')
def handle_my_custom_event(json):
    print('received json data here: ' + str(json))

if __name__ == "__main__":
   socketio.run(app, host='0.0.0.0', port=80, debug=0)
